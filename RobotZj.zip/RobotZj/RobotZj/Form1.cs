﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Numerics;

namespace RobotZj
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 定义机械臂矩阵，由机械臂尺寸决定
        /// </summary>
        public float[,] DH_JXB_ZJ = new float[6, 4] { { 0, 0, 144, 0 }, { 90, 0, 0, -90 }, { 0, -264, 0, 0 }, { 0, -236, 106, -90 }, { 90, 0, 114, 0 }, { -90, 0, 67, 0 } };
        public float[,] Theta = new float[1, 6];//六轴的角度
        public float[,] Pos = new float[1, 6];//正解出的姿态信息依次为X Y Z RALL PITCH YAW
        public float[,] Di = new float[1, 6];//关节偏距
        public float[,] Ai = new float[1, 6];//连杆长度
        public float[,] Alpha = new float[1, 6];//连杆转角
        public float[,] ThetaRad = new float[1, 6];//关节角
        public float[,] OffSet = new float[1, 6] { { 0, -90, 0, -90, 0, 0 } };//六轴关节初始角度
        public float Pi = 3.1415926f;
        public float X;//末端坐标
        public float Y;
        public float Z;
        public float Rall;//末端姿态
        public float Pitch;
        public float Yaw;
        float r;
        float p;
        float y;
        public Matrix4x4 T06 = new Matrix4x4();//正解转换矩阵
        public Matrix4x4 InversSolvtion = new Matrix4x4();
        public Form1()
        {
            InitializeComponent();


        }

        /// <summary>
        /// 正解算法，输入为六个轴的转角，输出为变换矩阵T06和姿态矩阵
        /// </summary>
        /// <param name="theta"></param>
        public void Zj(float[,] theta)
        {
            Di[0, 0] = DH_JXB_ZJ[0, 2];
            Di[0, 1] = DH_JXB_ZJ[1, 2];
            Di[0, 2] = DH_JXB_ZJ[2, 2];
            Di[0, 3] = DH_JXB_ZJ[3, 2];
            Di[0, 4] = DH_JXB_ZJ[4, 2];
            Di[0, 5] = DH_JXB_ZJ[5, 2];
            Ai[0, 0] = DH_JXB_ZJ[0, 1];
            Ai[0, 1] = DH_JXB_ZJ[1, 1];
            Ai[0, 2] = DH_JXB_ZJ[2, 1];
            Ai[0, 3] = DH_JXB_ZJ[3, 1];
            Ai[0, 4] = DH_JXB_ZJ[4, 1];
            Ai[0, 5] = DH_JXB_ZJ[5, 1];
            Alpha[0, 0] = (DH_JXB_ZJ[0, 0] / 180) * Pi;
            Alpha[0, 1] = (DH_JXB_ZJ[1, 0] / 180) * Pi;
            Alpha[0, 2] = (DH_JXB_ZJ[2, 0] / 180) * Pi;
            Alpha[0, 3] = (DH_JXB_ZJ[3, 0] / 180) * Pi;
            Alpha[0, 4] = (DH_JXB_ZJ[4, 0] / 180) * Pi;
            Alpha[0, 5] = (DH_JXB_ZJ[5, 0] / 180) * Pi;
            ThetaRad[0, 0] = (theta[0, 0] + OffSet[0, 0]) * Pi / 180;
            ThetaRad[0, 1] = (theta[0, 1] + OffSet[0, 1]) * Pi / 180;
            ThetaRad[0, 2] = (theta[0, 2] + OffSet[0, 2]) * Pi / 180;
            ThetaRad[0, 3] = (theta[0, 3] + OffSet[0, 3]) * Pi / 180;
            ThetaRad[0, 4] = (theta[0, 4] + OffSet[0, 4]) * Pi / 180;
            ThetaRad[0, 5] = (theta[0, 5] + OffSet[0, 5]) * Pi / 180;
            //坐标变换矩阵
            double[,] T01 = new double[4, 4]
            { { MathF.Cos(ThetaRad[0, 0]),-MathF.Sin(ThetaRad[0, 0]), 0 ,Ai[0,0] },
            {MathF.Sin(ThetaRad[0, 0])*MathF.Cos(Alpha[0,0]),MathF.Cos(ThetaRad[0, 0])*MathF.Cos(Alpha[0,0]),-MathF.Sin(Alpha[0,0]),-Di[0,0]*MathF.Sin(Alpha[0,0]) },
            {MathF.Sin(ThetaRad[0, 0])*MathF.Sin(Alpha[0,0]),MathF.Cos(ThetaRad[0, 0])*MathF.Sin(Alpha[0,0]),MathF.Cos(Alpha[0,0]),Di[0,0]*MathF.Cos(Alpha[0,0]) },
            {0          ,0          ,0          ,1 } };
            Matrix4x4 MartixT01 = new Matrix4x4(MathF.Cos(ThetaRad[0, 0]), -MathF.Sin(ThetaRad[0, 0]), 0, Ai[0, 0],
                                                MathF.Sin(ThetaRad[0, 0]) * MathF.Cos(Alpha[0, 0]), MathF.Cos(ThetaRad[0, 0]) * MathF.Cos(Alpha[0, 0]), -MathF.Sin(Alpha[0, 0]), -Di[0, 0] * MathF.Sin(Alpha[0, 0]),
                                                MathF.Sin(ThetaRad[0, 0]) * MathF.Sin(Alpha[0, 0]), MathF.Cos(ThetaRad[0, 0]) * MathF.Sin(Alpha[0, 0]), MathF.Cos(Alpha[0, 0]), Di[0, 0] * MathF.Cos(Alpha[0, 0]),
                                               0, 0, 0, 1);
            double[,] T12 = new double[4, 4]
            { { MathF.Cos(ThetaRad[0, 1]),-MathF.Sin(ThetaRad[0, 1]), 0 ,Ai[0,1] },
            {MathF.Sin(ThetaRad[0, 1])*MathF.Cos(Alpha[0,1]),MathF.Cos(ThetaRad[0, 1])*MathF.Cos(Alpha[0,1]),-MathF.Sin(Alpha[0,1]),-Di[0,1]*MathF.Sin(Alpha[0,1]) },
            {MathF.Sin(ThetaRad[0, 1])*MathF.Sin(Alpha[0,1]),MathF.Cos(ThetaRad[0, 1])*MathF.Sin(Alpha[0,1]),MathF.Cos(Alpha[0,1]),Di[0,1]*MathF.Cos(Alpha[0,1]) },
            {0          ,0          ,0          ,1 } };
            Matrix4x4 MartixT12 = new Matrix4x4(MathF.Cos(ThetaRad[0, 1]), -MathF.Sin(ThetaRad[0, 1]), 0, Ai[0, 1],
                                                MathF.Sin(ThetaRad[0, 1]) * MathF.Cos(Alpha[0, 1]), MathF.Cos(ThetaRad[0, 1]) * MathF.Cos(Alpha[0, 1]), -MathF.Sin(Alpha[0, 1]), -Di[0, 1] * MathF.Sin(Alpha[0, 1]),
                                                MathF.Sin(ThetaRad[0, 1]) * MathF.Sin(Alpha[0, 1]), MathF.Cos(ThetaRad[0, 1]) * MathF.Sin(Alpha[0, 1]), MathF.Cos(Alpha[0, 1]), Di[0, 1] * MathF.Cos(Alpha[0, 1]),
                                                0, 0, 0, 1);
            double[,] T23 = new double[4, 4]
            { { MathF.Cos(ThetaRad[0, 2]),-MathF.Sin(ThetaRad[0, 2]), 0 ,Ai[0,2] },
            {MathF.Sin(ThetaRad[0, 2])*MathF.Cos(Alpha[0,2]),MathF.Cos(ThetaRad[0, 2])*MathF.Cos(Alpha[0,2]),-MathF.Sin(Alpha[0,2]),-Di[0,2]*MathF.Sin(Alpha[0,2]) },
            {MathF.Sin(ThetaRad[0, 2])*MathF.Sin(Alpha[0,2]),MathF.Cos(ThetaRad[0, 2])*MathF.Sin(Alpha[0,2]),MathF.Cos(Alpha[0,2]),Di[0,2]*MathF.Cos(Alpha[0,2]) },
            {0          ,0          ,0          ,1 } };
            Matrix4x4 MartixT23 = new Matrix4x4(MathF.Cos(ThetaRad[0, 2]), -MathF.Sin(ThetaRad[0, 2]), 0, Ai[0, 2],
                                                MathF.Sin(ThetaRad[0, 2]) * MathF.Cos(Alpha[0, 2]), MathF.Cos(ThetaRad[0, 2]) * MathF.Cos(Alpha[0, 2]), -MathF.Sin(Alpha[0, 2]), -Di[0, 2] * MathF.Sin(Alpha[0, 2]),
                                                MathF.Sin(ThetaRad[0, 2]) * MathF.Sin(Alpha[0, 2]), MathF.Cos(ThetaRad[0, 2]) * MathF.Sin(Alpha[0, 2]), MathF.Cos(Alpha[0, 2]), Di[0, 2] * MathF.Cos(Alpha[0, 2]),
                                                0, 0, 0, 1);
            double[,] T34 = new double[4, 4]
            { { MathF.Cos(ThetaRad[0, 3]),-MathF.Sin(ThetaRad[0, 3]), 0 ,Ai[0,3] },
            {MathF.Sin(ThetaRad[0, 3])*MathF.Cos(Alpha[0,3]),MathF.Cos(ThetaRad[0, 3])*MathF.Cos(Alpha[0,3]),-MathF.Sin(Alpha[0,3]),-Di[0,3]*MathF.Sin(Alpha[0,3]) },
            {MathF.Sin(ThetaRad[0, 3])*MathF.Sin(Alpha[0,3]),MathF.Cos(ThetaRad[0, 3])*MathF.Sin(Alpha[0,3]),MathF.Cos(Alpha[0,3]),Di[0,3]*MathF.Cos(Alpha[0,3]) },
            {0          ,0          ,0          ,1 } };
            Matrix4x4 MartixT34 = new Matrix4x4(MathF.Cos(ThetaRad[0, 3]), -MathF.Sin(ThetaRad[0, 3]), 0, Ai[0, 3],
                                                MathF.Sin(ThetaRad[0, 3]) * MathF.Cos(Alpha[0, 3]), MathF.Cos(ThetaRad[0, 3]) * MathF.Cos(Alpha[0, 3]), -MathF.Sin(Alpha[0, 3]), -Di[0, 3] * MathF.Sin(Alpha[0, 3]),
                                                MathF.Sin(ThetaRad[0, 3]) * MathF.Sin(Alpha[0, 3]), MathF.Cos(ThetaRad[0, 3]) * MathF.Sin(Alpha[0, 3]), MathF.Cos(Alpha[0, 3]), Di[0, 3] * MathF.Cos(Alpha[0, 3]),
                                                0, 0, 0, 1);
            double[,] T45 = new double[4, 4]
            { { MathF.Cos(ThetaRad[0, 4]),-MathF.Sin(ThetaRad[0, 4]), 0 ,Ai[0,4] },
            {MathF.Sin(ThetaRad[0, 4])*MathF.Cos(Alpha[0,4]),MathF.Cos(ThetaRad[0, 4])*MathF.Cos(Alpha[0,4]),-MathF.Sin(Alpha[0,4]),-Di[0,4]*MathF.Sin(Alpha[0,4]) },
            {MathF.Sin(ThetaRad[0, 4])*MathF.Sin(Alpha[0,4]),MathF.Cos(ThetaRad[0, 4])*MathF.Sin(Alpha[0,4]),MathF.Cos(Alpha[0,4]),Di[0,4]*MathF.Cos(Alpha[0,4]) },
            {0          ,0          ,0          ,1 } };
            Matrix4x4 MartixT45 = new Matrix4x4(MathF.Cos(ThetaRad[0, 4]), -MathF.Sin(ThetaRad[0, 4]), 0, Ai[0, 4],
                                                MathF.Sin(ThetaRad[0, 4]) * MathF.Cos(Alpha[0, 4]), MathF.Cos(ThetaRad[0, 4]) * MathF.Cos(Alpha[0, 4]), -MathF.Sin(Alpha[0,4]), -Di[0, 4] * MathF.Sin(Alpha[0, 4]),
                                                MathF.Sin(ThetaRad[0, 4]) * MathF.Sin(Alpha[0, 4]), MathF.Cos(ThetaRad[0, 4]) * MathF.Sin(Alpha[0, 4]), MathF.Cos(Alpha[0, 4]), Di[0, 4] * MathF.Cos(Alpha[0, 4]),
                                                0, 0, 0, 1);
            double[,] T56 = new double[4, 4]
            { { MathF.Cos(ThetaRad[0, 5]),-MathF.Sin(ThetaRad[0, 5]), 0 ,Ai[0,5] },
            {MathF.Sin(ThetaRad[0, 5])*MathF.Cos(Alpha[0,5]),MathF.Cos(ThetaRad[0, 5])*MathF.Cos(Alpha[0,5]),-MathF.Sin(Alpha[0,5]),-Di[0,5]*MathF.Sin(Alpha[0,5]) },
            {MathF.Sin(ThetaRad[0, 5])*MathF.Sin(Alpha[0,5]),MathF.Cos(ThetaRad[0, 5])*MathF.Sin(Alpha[0,5]),MathF.Cos(Alpha[0,5]),Di[0,5]*MathF.Cos(Alpha[0,5]) },
            {0          ,0          ,0          ,1 } };
            Matrix4x4 MartixT56 = new Matrix4x4(MathF.Cos(ThetaRad[0, 5]), -MathF.Sin(ThetaRad[0, 5]), 0, Ai[0, 5],
                                                MathF.Sin(ThetaRad[0, 5]) * MathF.Cos(Alpha[0, 5]), MathF.Cos(ThetaRad[0, 5]) * MathF.Cos(Alpha[0, 5]), -MathF.Sin(Alpha[0, 5]), -Di[0, 5] * MathF.Sin(Alpha[0, 5]),
                                                MathF.Sin(ThetaRad[0, 5]) * MathF.Sin(Alpha[0, 5]), MathF.Cos(ThetaRad[0, 5]) * MathF.Sin(Alpha[0, 5]), MathF.Cos(Alpha[0, 5]), Di[0, 5] * MathF.Cos(Alpha[0, 5]),
                                                0, 0, 0, 1);
            Matrix4x4 MartixT1 = new Matrix4x4();
            Matrix4x4 MartixT2 = new Matrix4x4();
            Matrix4x4 MartixT3 = new Matrix4x4();
            Matrix4x4 MartixT4 = new Matrix4x4();
            MartixT1 = Matrix4x4.Multiply(MartixT01, MartixT12);
            MartixT2 = Matrix4x4.Multiply(MartixT23, MartixT34);
            MartixT3 = Matrix4x4.Multiply(MartixT45, MartixT56);
            MartixT4 = Matrix4x4.Multiply(MartixT1, MartixT2);
            T06= Matrix4x4.Multiply(MartixT4, MartixT3);
            X = MathF.Round(T06.M14, 2);
            Y = MathF.Round(T06.M24, 2);
            Z = MathF.Round(T06.M34, 2);
            textBox12.Text = X.ToString();
            textBox11.Text = Y.ToString();
            textBox10.Text = Z.ToString();
            float[,] rpy = new float[1,3];
            if (Math.Abs(Math.Abs(MathF.Round(T06.M13, 2)) - 1) == 0)
            {
                rpy[0, 0] = 0;
                if (T06.M13 > 0)
                {
                    rpy[0, 2] = MathF.Atan2(MathF.Round(T06.M32, 2), MathF.Round(T06.M22, 2));
                }
                else
                {
                    rpy[0, 2] = MathF.Atan2(MathF.Round(T06.M21, 2), MathF.Round(T06.M31, 2));
                }
                rpy[0, 1] = MathF.Asin(MathF.Round(T06.M13, 2));

            }
            else {
                rpy[0, 0] =-MathF.Atan2(MathF.Round(T06.M12, 2), MathF.Round(T06.M11, 2));
                rpy[0, 2] = -MathF.Atan2(MathF.Round(T06.M23, 2), MathF.Round(T06.M33, 2)); ;
                rpy[0, 1] =MathF.Atan(MathF.Round(T06.M13,2)*MathF.Cos(rpy[0,0]/ MathF.Round(T06.M11, 2)));
            }
            Rall = MathF.Round(rpy[0, 0] * 180 / Pi, 4); 
            Pitch = MathF.Round(rpy[0, 1] * 180 / Pi, 4);
            Yaw = MathF.Round(rpy[0, 2] * 180 / Pi, 4);
            r = Rall;
            p = Pitch;
            y = Yaw;
            textBox9.Text = Rall.ToString();
            textBox8.Text = Pitch.ToString();
            textBox7.Text = Yaw.ToString();
        }

        /// <summary>
        /// 逆解算法，输入为末端位置和姿态，输出为每个轴的转角
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Nj()
        {
            //连杆偏移
            float d1 = DH_JXB_ZJ[0, 2]; 
            float d2 = DH_JXB_ZJ[1, 2];
            float d3 = DH_JXB_ZJ[2, 2];
            float d4 = DH_JXB_ZJ[3, 2];
            float d5 = DH_JXB_ZJ[4, 2];
            float d6 = DH_JXB_ZJ[5, 2];
            //连杆长度
            float a1 = DH_JXB_ZJ[0, 1];
            float a2 = DH_JXB_ZJ[2, 1];
            float a3 = DH_JXB_ZJ[3, 1];
            float a4 = DH_JXB_ZJ[3, 1];
            float a5 = DH_JXB_ZJ[4, 1];
            float a6 = DH_JXB_ZJ[5, 1];
            //连杆扭角
            float alpha1 = DH_JXB_ZJ[0, 0];
            float alpha2 = DH_JXB_ZJ[1, 0];
            float alpha3 = DH_JXB_ZJ[2, 0];
            float alpha4 = DH_JXB_ZJ[3, 0];
            float alpha5 = DH_JXB_ZJ[4, 0];
            float alpha6 = DH_JXB_ZJ[5, 0];
            //目标位置姿态矩阵
            float nx = T06.M11;
            float ny = T06.M21;
            float nz = T06.M31;
            float ox = T06.M12;
            float oy = T06.M22;
            float oz = T06.M32;
            float ax = T06.M13;
            float ay = T06.M23;
            float az = T06.M33;
            float px = T06.M14;
            float py = T06.M24;
            float pz = T06.M34;
            //求解关节角1
            float theta1_1 = MathF.Atan2(d4, MathF.Sqrt(MathF.Pow(d6 * ay - py, 2) + MathF.Pow((px - d6 * ax), 2) - MathF.Pow(d4, 2)))-MathF.Atan2(d6 * ay - py, px - d6 * ax);
            float theta1_2 = MathF.Atan2(d4, -MathF.Sqrt(MathF.Pow(d6 * ay - py, 2) + MathF.Pow((px - d6 * ax), 2) - MathF.Pow(d4, 2))) - MathF.Atan2(d6 * ay - py, px - d6 * ax);
            //求解关节角5
            float theta5_1 = MathF.Atan2(MathF.Sqrt(MathF.Pow(nx * MathF.Sin(theta1_1) - ny * MathF.Cos(theta1_1), 2) + MathF.Pow(ox * MathF.Sin(theta1_1) - oy * MathF.Cos(theta1_1), 2)), ax * MathF.Sin(theta1_1) - ay * MathF.Cos(theta1_1));
            float theta5_2 = MathF.Atan2(-MathF.Sqrt(MathF.Pow(nx * MathF.Sin(theta1_1) - ny * MathF.Cos(theta1_1), 2) + MathF.Pow(ox * MathF.Sin(theta1_1) - oy * MathF.Cos(theta1_1), 2)), ax * MathF.Sin(theta1_1) - ay * MathF.Cos(theta1_1));
            float theta5_3 = MathF.Atan2(MathF.Sqrt(MathF.Pow(nx * MathF.Sin(theta1_2) - ny * MathF.Cos(theta1_2), 2) + MathF.Pow(ox * MathF.Sin(theta1_2) - oy * MathF.Cos(theta1_2), 2)), ax * MathF.Sin(theta1_2) - ay * MathF.Cos(theta1_2));
            float theta5_4 = MathF.Atan2(-MathF.Sqrt(MathF.Pow(nx * MathF.Sin(theta1_2) - ny * MathF.Cos(theta1_2), 2) + MathF.Pow(ox * MathF.Sin(theta1_2) - oy * MathF.Cos(theta1_2), 2)), ax * MathF.Sin(theta1_2) - ay * MathF.Cos(theta1_2));
            //求解关节角6
            float theta6_1 = MathF.Atan2(-(ox * MathF.Sin(theta1_1) - oy * MathF.Cos(theta1_1)) / MathF.Sin(theta5_1), (nx * MathF.Sin(theta1_1) - ny * MathF.Cos(theta1_1)) / MathF.Sin(theta5_1));
            float theta6_2 = MathF.Atan2(-(ox * MathF.Sin(theta1_1) - oy * MathF.Cos(theta1_1)) / MathF.Sin(theta5_2), (nx * MathF.Sin(theta1_1) - ny * MathF.Cos(theta1_1)) / MathF.Sin(theta5_2));
            float theta6_3 = MathF.Atan2(-(ox * MathF.Sin(theta1_2) - oy * MathF.Cos(theta1_2)) / MathF.Sin(theta5_3), (nx * MathF.Sin(theta1_2) - ny * MathF.Cos(theta1_2)) / MathF.Sin(theta5_3));
            float theta6_4 = MathF.Atan2(-(ox * MathF.Sin(theta1_2) - oy * MathF.Cos(theta1_2)) / MathF.Sin(theta5_4), (nx * MathF.Sin(theta1_2) - ny * MathF.Cos(theta1_2)) / MathF.Sin(theta5_4));
            //求解关节角2，3，4
            float q234_1 = MathF.Atan2(-az / MathF.Sin(theta5_1), -(ax * MathF.Cos(theta1_1) + ay * MathF.Sin(theta1_1)) / MathF.Sin(theta5_1));
            float q234_2 = MathF.Atan2(-az / MathF.Sin(theta5_2), -(ax * MathF.Cos(theta1_1) + ay * MathF.Sin(theta1_1)) / MathF.Sin(theta5_2));
            float q234_3 = MathF.Atan2(-az / MathF.Sin(theta5_3), -(ax * MathF.Cos(theta1_2) + ay * MathF.Sin(theta1_2)) / MathF.Sin(theta5_3));
            float q234_4 = MathF.Atan2(-az / MathF.Sin(theta5_4), -(ax * MathF.Cos(theta1_2) + ay * MathF.Sin(theta1_2)) / MathF.Sin(theta5_4));

            float A_1 = px * MathF.Cos(theta1_1) + py * MathF.Sin(theta1_1) - d5 * MathF.Sin(q234_1) + d6 * MathF.Sin(theta5_1) * MathF.Cos(q234_1);
            float B_1 = pz - d1 + d5 * MathF.Cos(q234_1) + d6 * MathF.Sin(theta5_1) * MathF.Sin(q234_1);
            float A_2 = px * MathF.Cos(theta1_1) + py * MathF.Sin(theta1_1) - d5 * MathF.Sin(q234_2) + d6 * MathF.Sin(theta5_2) * MathF.Cos(q234_2);
            float B_2 = pz - d1 + d5 * MathF.Cos(q234_2) + d6 * MathF.Sin(theta5_2) * MathF.Sin(q234_2);
            float A_3 = px * MathF.Cos(theta1_2) + py * MathF.Sin(theta1_2) - d5 * MathF.Sin(q234_3) + d6 * MathF.Sin(theta5_3) * MathF.Cos(q234_3);
            float B_3 = pz - d1 + d5 * MathF.Cos(q234_3) + d6 * MathF.Sin(theta5_3) * MathF.Sin(q234_3);
            float A_4 = px * MathF.Cos(theta1_2) + py * MathF.Sin(theta1_2) - d5 * MathF.Sin(q234_4) + d6 * MathF.Sin(theta5_4) * MathF.Cos(q234_4);
            float B_4 = pz - d1 + d5 * MathF.Cos(q234_4) + d6 * MathF.Sin(theta5_4) * MathF.Sin(q234_4);

           
            float theta2_1 = MathF.Atan2(A_1 * A_1 + B_1 * B_1 + a2 * a2 - a3 * a3, MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_1 * A_1 + B_1 * B_1) - MathF.Pow(A_1 * A_1 + B_1 * B_1 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_1, B_1);       
            float theta2_2 = MathF.Atan2(A_1 * A_1 + B_1 * B_1 + a2 * a2 - a3 * a3, -MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_1 * A_1 + B_1 * B_1) - MathF.Pow(A_1 * A_1 + B_1 * B_1 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_1, B_1);
            float theta2_3 = MathF.Atan2(A_2 * A_2 + B_2 * B_2 + a2 * a2 - a3 * a3, MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_2 * A_2 + B_2 * B_2) - MathF.Pow(A_2 * A_2 + B_2 * B_2 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_2, B_2);
            float theta2_4 = MathF.Atan2(A_2 * A_2 + B_2 * B_2 + a2 * a2 - a3 * a3, -MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_2 * A_2 + B_2 * B_2) - MathF.Pow(A_2 * A_2 + B_2 * B_2 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_2, B_2);
            float theta2_5 = MathF.Atan2(A_3 * A_3 + B_3 * B_3 + a2 * a2 - a3 * a3, MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_3 * A_3 + B_3 * B_3) - MathF.Pow(A_3 * A_3 + B_3 * B_3 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_3, B_3);
            float theta2_6 = MathF.Atan2(A_3 * A_3 + B_3 * B_3 + a2 * a2 - a3 * a3, -MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_3 * A_3 + B_3 * B_3) - MathF.Pow(A_3 * A_3 + B_3 * B_3 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_3, B_3);
            float theta2_7 = MathF.Atan2(A_4 * A_4 + B_4 * B_4 + a2 * a2 - a3 * a3, MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_4 * A_4 + B_4 * B_4) - MathF.Pow(A_4 * A_4 + B_4 * B_4 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_4, B_4);
            float theta2_8 = MathF.Atan2(A_4 * A_4 + B_4 * B_4 + a2 * a2 - a3 * a3, -MathF.Sqrt(MathF.Abs(4 * a2 * a2 * (A_4 * A_4 + B_4 * B_4) - MathF.Pow(A_4 * A_4 + B_4 * B_4 + a2 * a2 - a3 * a3, 2)))) - MathF.Atan2(A_4, B_4);


            float q23_1 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_1) + d6 * MathF.Sin(theta5_1) * MathF.Sin(q234_1) - a2 * MathF.Sin(theta2_1), px * MathF.Cos(theta1_1) + py * MathF.Sin(theta1_1) - d5 * MathF.Sin(q234_1) + d6 * MathF.Sin(theta5_1) * MathF.Cos(q234_1) - a2 * MathF.Cos(theta2_1));
            float q23_2 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_1) + d6 * MathF.Sin(theta5_1) * MathF.Sin(q234_1) - a2 * MathF.Sin(theta2_2), px * MathF.Cos(theta1_1) + py * MathF.Sin(theta1_1) - d5 * MathF.Sin(q234_1) + d6 * MathF.Sin(theta5_1) * MathF.Cos(q234_1) - a2 * MathF.Cos(theta2_2));
            float q23_3 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_2) + d6 * MathF.Sin(theta5_2) * MathF.Sin(q234_2) - a2 * MathF.Sin(theta2_3), px * MathF.Cos(theta1_1) + py * MathF.Sin(theta1_1) - d5 * MathF.Sin(q234_2) + d6 * MathF.Sin(theta5_2) * MathF.Cos(q234_2) - a2 * MathF.Cos(theta2_3));
            float q23_4 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_2) + d6 * MathF.Sin(theta5_2) * MathF.Sin(q234_2) - a2 * MathF.Sin(theta2_4), px * MathF.Cos(theta1_1) + py * MathF.Sin(theta1_1) - d5 * MathF.Sin(q234_2) + d6 * MathF.Sin(theta5_2) * MathF.Cos(q234_2) - a2 * MathF.Cos(theta2_4));
            float q23_5 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_3) + d6 * MathF.Sin(theta5_3) * MathF.Sin(q234_3) - a2 * MathF.Sin(theta2_5), px * MathF.Cos(theta1_2) + py * MathF.Sin(theta1_2) - d5 * MathF.Sin(q234_3) + d6 * MathF.Sin(theta5_3) * MathF.Cos(q234_3) - a2 * MathF.Cos(theta2_5));
            float q23_6 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_3) + d6 * MathF.Sin(theta5_3) * MathF.Sin(q234_3) - a2 * MathF.Sin(theta2_6), px * MathF.Cos(theta1_2) + py * MathF.Sin(theta1_2) - d5 * MathF.Sin(q234_3) + d6 * MathF.Sin(theta5_3) * MathF.Cos(q234_3) - a2 * MathF.Cos(theta2_6));
            float q23_7 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_4) + d6 * MathF.Sin(theta5_4) * MathF.Sin(q234_4) - a2 * MathF.Sin(theta2_7), px * MathF.Cos(theta1_2) + py * MathF.Sin(theta1_2) - d5 * MathF.Sin(q234_4) + d6 * MathF.Sin(theta5_4) * MathF.Cos(q234_4) - a2 * MathF.Cos(theta2_7));
            float q23_8 = MathF.Atan2(pz - d1 + d5 * MathF.Cos(q234_4) + d6 * MathF.Sin(theta5_4) * MathF.Sin(q234_4) - a2 * MathF.Sin(theta2_8), px * MathF.Cos(theta1_2) + py * MathF.Sin(theta1_2) - d5 * MathF.Sin(q234_4) + d6 * MathF.Sin(theta5_4) * MathF.Cos(q234_4) - a2 * MathF.Cos(theta2_8));

            float theta3_1 = q23_1 - theta2_1;
            float theta3_2 = q23_2 - theta2_2;
            float theta3_3 = q23_3 - theta2_3;
            float theta3_4 = q23_4 - theta2_4;
            float theta3_5 = q23_5 - theta2_5;
            float theta3_6 = q23_6 - theta2_6;
            float theta3_7 = q23_7 - theta2_7;
            float theta3_8 = q23_8 - theta2_8;

            float theta4_1 = q234_1 - q23_1;
            float theta4_2 = q234_1 - q23_2;
            float theta4_3 = q234_2 - q23_3;
            float theta4_4 = q234_2 - q23_4;
            float theta4_5 = q234_3 - q23_5;
            float theta4_6 = q234_3 - q23_6;
            float theta4_7 = q234_4 - q23_7;
            float theta4_8 = q234_4 - q23_8;

            float[,]InverseSolvtion=new float[8, 6]{{theta1_1, theta2_1, theta3_1, theta4_1, theta5_1, theta6_1},
                                                    {theta1_1, theta2_2, theta3_2, theta4_2, theta5_1, theta6_1},
                                                    {theta1_1, theta2_3, theta3_3, theta4_3, theta5_2, theta6_2},
                                                    {theta1_1, theta2_4, theta3_4, theta4_4, theta5_2, theta6_2},
                                                    {theta1_2, theta2_5, theta3_5, theta4_5, theta5_3, theta6_3},
                                                    {theta1_2, theta2_6, theta3_6, theta4_6, theta5_3, theta6_3},
                                                    {theta1_2, theta2_7, theta3_7, theta4_7, theta5_4, theta6_4},
                                                    {theta1_2, theta2_8, theta3_8, theta4_8, theta5_4, theta6_4}};
            //string result = "";
            //foreach (float flo in InverseSolvtion)
            //{
            //    result += flo.ToString() + ",";
            //}
            //textBox13.Text = result;0.5235987
            //MessageBox.Show("result=" + result);
            MessageBox.Show("theta2_5=" + theta2_5 * 180 / Pi);

        }

        public void InverSolvtion(float x,float y,float z,float rall,float pitch,float yaw)
        {
            float p2 = DH_JXB_ZJ[1, 3];
            float p4 = DH_JXB_ZJ[3, 3];
            float a2 = DH_JXB_ZJ[2, 1];
            float a3 = DH_JXB_ZJ[3, 1];
            float a6 = 0;
            float afa6 = 0;
            float d1 = DH_JXB_ZJ[0, 2];
            float d4 = DH_JXB_ZJ[3, 2];
            float d5 = DH_JXB_ZJ[4, 2];
            float d7 = DH_JXB_ZJ[5, 2];
            float X = x;
            float Y = y;
            float Z = z;
            float gama = rall * Pi / 180;
            float beta = pitch * Pi / 180;
            float alpha = yaw * Pi / 180;
            float theta7 = 0;
            Matrix4x4 T67 = new Matrix4x4(MathF.Cos(theta7), -MathF.Sin(theta7), 0, a6,
                                          MathF.Sin(theta7) * MathF.Cos(theta7), MathF.Cos(theta7) * MathF.Cos(afa6), -MathF.Sin(afa6), -MathF.Sin(afa6) * d7,
                                          MathF.Sin(theta7) * MathF.Sin(theta7), MathF.Cos(theta7) * MathF.Sin(afa6), MathF.Cos(afa6), MathF.Cos(afa6) * d7,
                                          0,0,0,1);
            Matrix4x4 T_goat = new Matrix4x4(MathF.Cos(beta)*MathF.Cos(gama), -MathF.Cos(beta) * MathF.Sin(gama),MathF.Sin(beta),X,
                                            MathF.Sin(alpha)*MathF.Sin(beta)*MathF.Cos(gama)+MathF.Cos(alpha)*MathF.Sin(gama),-MathF.Sin(alpha) * MathF.Sin(beta) * MathF.Sin(gama) + MathF.Cos(alpha) * MathF.Cos(gama),-MathF.Sin(alpha)*MathF.Cos(beta),Y,
                                            -MathF.Cos(alpha) * MathF.Sin(beta) * MathF.Cos(gama) + MathF.Sin(alpha) * MathF.Sin(gama), MathF.Cos(alpha) * MathF.Sin(beta) * MathF.Sin(gama) + MathF.Sin(alpha) * MathF.Cos(gama), MathF.Cos(alpha) * MathF.Cos(beta), Z,
                                            0,0,0,1);
            Matrix4x4 T06_new = new Matrix4x4();
            Matrix4x4 T67_new = new Matrix4x4();
            bool success = Matrix4x4.Invert(T67, out T67_new);
            if (success)
            {
                T06_new = Matrix4x4.Multiply(T06, T67_new);
            }
            float nx = T06_new.M11;
            float ny = T06_new.M21;
            float nz = T06_new.M31;
            float ox = T06_new.M12;
            float oy = T06_new.M22;
            float oz = T06_new.M32;
            float ax = T06_new.M13;
            float ay = T06_new.M23;
            float az = T06_new.M33;
            float px = T06_new.M14;
            float py = T06_new.M24;
            float pz = T06_new.M34;
            if (px * px + py * py - d4 * d4 <= 0)
            {
                MessageBox.Show("cant solve");
            }
            else {
                float theta1_1 = MathF.Atan2(py, px) - MathF.Atan2(-d4, MathF.Sqrt(px * px + py * py - d4 * d4));
                float theta1_2 = MathF.Atan2(py, px) - MathF.Atan2(-d4, -MathF.Sqrt(px * px + py * py - d4 * d4));
                float S5_1 = MathF.Sqrt(MathF.Pow(-MathF.Sin(theta1_1) * nx + MathF.Cos(theta1_1) * ny, 2) + MathF.Pow(-MathF.Sin(theta1_1) * ox + MathF.Cos(theta1_1) * oy, 2));
                float S5_2 = -MathF.Sqrt(MathF.Pow(-MathF.Sin(theta1_1) * nx + MathF.Cos(theta1_1) * ny, 2) + MathF.Pow(-MathF.Sin(theta1_1) * ox + MathF.Cos(theta1_1) * oy, 2));
                float S5_3 = MathF.Sqrt(MathF.Pow(-MathF.Sin(theta1_2) * nx + MathF.Cos(theta1_2) * ny, 2) + MathF.Pow(-MathF.Sin(theta1_2) * ox + MathF.Cos(theta1_2) * oy, 2));
                float S5_4 = -MathF.Sqrt(MathF.Pow(-MathF.Sin(theta1_2) * nx + MathF.Cos(theta1_2) * ny, 2) + MathF.Pow(-MathF.Sin(theta1_2) * ox + MathF.Cos(theta1_2) * oy, 2));
                float theta5_1 = MathF.Atan2(S5_1, MathF.Sin(theta1_1) * ax - MathF.Cos(theta1_1) * ay);
                float theta5_2 = MathF.Atan2(S5_2, MathF.Sin(theta1_1) * ax - MathF.Cos(theta1_1) * ay);
                float theta5_3 = MathF.Atan2(S5_3, MathF.Sin(theta1_2) * ax - MathF.Cos(theta1_2) * ay);
                float theta5_4 = MathF.Atan2(S5_4, MathF.Sin(theta1_2) * ax - MathF.Cos(theta1_2) * ay);

                float theta6_1=MathF.Atan2((-MathF.Sin(theta1_1)*ox+MathF.Cos(theta1_1)*oy)/MathF.Sin(theta5_1), (MathF.Sin(theta1_1) * nx - MathF.Cos(theta1_1) * ny) / MathF.Sin(theta5_1));
                float theta6_2=MathF.Atan2((-MathF.Sin(theta1_1)*ox+MathF.Cos(theta1_1)*oy)/MathF.Sin(theta5_2), (MathF.Sin(theta1_1) * nx - MathF.Cos(theta1_1) * ny) / MathF.Sin(theta5_2));
                float theta6_3=MathF.Atan2((-MathF.Sin(theta1_2)*ox+MathF.Cos(theta1_2)*oy)/MathF.Sin(theta5_3), (MathF.Sin(theta1_2) * nx - MathF.Cos(theta1_2) * ny) / MathF.Sin(theta5_3));
                float theta6_4=MathF.Atan2((-MathF.Sin(theta1_2)*ox+MathF.Cos(theta1_2)*oy)/MathF.Sin(theta5_4), (MathF.Sin(theta1_2) * nx - MathF.Cos(theta1_2) * ny) / MathF.Sin(theta5_4));

                float q234_1 = MathF.Atan2(-az / MathF.Sin(theta5_1), -(ax * MathF.Cos(theta1_1) + ay * MathF.Sin(theta1_1)) / MathF.Sin(theta5_1));
                float q234_2 = MathF.Atan2(-az / MathF.Sin(theta5_2), -(ax * MathF.Cos(theta1_1) + ay * MathF.Sin(theta1_1)) / MathF.Sin(theta5_2));
                float q234_3 = MathF.Atan2(-az / MathF.Sin(theta5_3), -(ax * MathF.Cos(theta1_2) + ay * MathF.Sin(theta1_2)) / MathF.Sin(theta5_3));
                float q234_4 = MathF.Atan2(-az / MathF.Sin(theta5_4), -(ax * MathF.Cos(theta1_2) + ay * MathF.Sin(theta1_2)) / MathF.Sin(theta5_4));

                float B_1_1 = MathF.Cos(theta1_1) * px + MathF.Sin(theta1_1) * py - d5 * MathF.Sin(q234_1);
                float B_1_2 = MathF.Cos(theta1_1) * px + MathF.Sin(theta1_1) * py - d5 * MathF.Sin(q234_2);
                float B_1_3 = MathF.Cos(theta1_2) * px + MathF.Sin(theta1_2) * py - d5 * MathF.Sin(q234_3);
                float B_1_4 = MathF.Cos(theta1_2) * px + MathF.Sin(theta1_2) * py - d5 * MathF.Sin(q234_4);
                float B_2_1 = pz - d1 + d5 * MathF.Cos(q234_1);
                float B_2_2 = pz - d1 + d5 * MathF.Cos(q234_2);
                float B_2_3 = pz - d1 + d5 * MathF.Cos(q234_3);
                float B_2_4 = pz - d1 + d5 * MathF.Cos(q234_4);
                float C_1 = B_1_1 * B_1_1 + B_2_1 * B_2_1 + a2 * a2 - a3 * a3;
                float C_2 = B_1_2 * B_1_2 + B_2_2 * B_2_2 + a2 * a2 - a3 * a3;
                float C_3 = B_1_3 * B_1_3 + B_2_3 * B_2_3 + a2 * a2 - a3 * a3;
                float C_4 = B_1_4 * B_1_4 + B_2_4 * B_2_4 + a2 * a2 - a3 * a3;
                float A_1 = -2 * B_2_1 * a2;
                float A_2 = -2 * B_2_2 * a2;
                float A_3 = -2 * B_2_3 * a2;
                float A_4 = -2 * B_2_4 * a2;
                float B_1 = 2 * B_1_1 * a2;
                float B_2 = 2 * B_1_2 * a2;
                float B_3 = 2 * B_1_3 * a2;
                float B_4 = 2 * B_1_4 * a2;
                float theta2_1 = MathF.Atan2(B_1, A_1) - MathF.Atan2(C_1, MathF.Sqrt(A_1 * A_1 + B_1 * B_1 - C_1 * C_1));
                float theta2_2 = MathF.Atan2(B_1, A_1) - MathF.Atan2(C_1, -MathF.Sqrt(A_1 * A_1 + B_1 * B_1 - C_1 * C_1));
                float theta2_3 = MathF.Atan2(B_2, A_2) - MathF.Atan2(C_2, MathF.Sqrt(A_2 * A_2 + B_2 * B_2 - C_2 * C_2));
                float theta2_4 = MathF.Atan2(B_2, A_2) - MathF.Atan2(C_2, -MathF.Sqrt(A_2 * A_2 + B_2 * B_2 - C_2 * C_2));
                float theta2_5 = MathF.Atan2(B_3, A_3) - MathF.Atan2(C_3, MathF.Sqrt(A_3 * A_3 + B_3 * B_3 - C_3 * C_3));
                float theta2_6 = MathF.Atan2(B_3, A_3) - MathF.Atan2(C_3, -MathF.Sqrt(A_3 * A_3 + B_3 * B_3 - C_3 * C_3));
                float theta2_7 = MathF.Atan2(B_4, A_4) - MathF.Atan2(C_4, MathF.Sqrt(A_4 * A_4 + B_4 * B_4 - C_4 * C_4));
                float theta2_8 = MathF.Atan2(B_4, A_4) - MathF.Atan2(C_4, -MathF.Sqrt(A_4 * A_4 + B_4 * B_4 - C_4 * C_4));

                float q23_1 = MathF.Atan2((B_2_1 - a2 * MathF.Sin(theta2_1)) / a3, (B_1_1 - a2 * MathF.Cos(theta2_1)) / a3);
                float q23_2 = MathF.Atan2((B_2_1 - a2 * MathF.Sin(theta2_2)) / a3, (B_1_1 - a2 * MathF.Cos(theta2_2)) / a3);
                float q23_3 = MathF.Atan2((B_2_2 - a2 * MathF.Sin(theta2_3)) / a3, (B_1_2 - a2 * MathF.Cos(theta2_3)) / a3);
                float q23_4 = MathF.Atan2((B_2_2 - a2 * MathF.Sin(theta2_4)) / a3, (B_1_2 - a2 * MathF.Cos(theta2_4)) / a3);
                float q23_5 = MathF.Atan2((B_2_3 - a2 * MathF.Sin(theta2_5)) / a3, (B_1_3 - a2 * MathF.Cos(theta2_4)) / a3);
                float q23_6 = MathF.Atan2((B_2_3 - a2 * MathF.Sin(theta2_6)) / a3, (B_1_3 - a2 * MathF.Cos(theta2_6)) / a3);
                float q23_7 = MathF.Atan2((B_2_4 - a2 * MathF.Sin(theta2_7)) / a3, (B_1_4 - a2 * MathF.Cos(theta2_7)) / a3);
                float q23_8 = MathF.Atan2((B_2_4 - a2 * MathF.Sin(theta2_8)) / a3, (B_1_4 - a2 * MathF.Cos(theta2_8)) / a3);

                float theta3_1 = q23_1 - theta2_1;
                float theta3_2 = q23_2 - theta2_2;
                float theta3_3 = q23_3 - theta2_3;
                float theta3_4 = q23_4 - theta2_4;
                float theta3_5 = q23_5 - theta2_5;
                float theta3_6 = q23_6 - theta2_6;
                float theta3_7 = q23_7 - theta2_7;
                float theta3_8 = q23_8 - theta2_8;

                float theta4_1 = q234_1 - q23_1;
                float theta4_2 = q234_1 - q23_2;
                float theta4_3 = q234_2 - q23_3;
                float theta4_4 = q234_2 - q23_4;
                float theta4_5 = q234_3 - q23_5;
                float theta4_6 = q234_3 - q23_6;
                float theta4_7 = q234_4 - q23_7;
                float theta4_8 = q234_4 - q23_8;

                float[,] InverseSolvtion = new float[8, 6]{{theta1_1, theta2_1, theta3_1, theta4_1, theta5_1, theta6_1},
                                                    {theta1_1, theta2_2, theta3_2, theta4_2, theta5_1, theta6_1},
                                                    {theta1_1, theta2_3, theta3_3, theta4_3, theta5_2, theta6_2},
                                                    {theta1_1, theta2_4, theta3_4, theta4_4, theta5_2, theta6_2},
                                                    {theta1_2, theta2_5, theta3_5, theta4_5, theta5_3, theta6_3},
                                                    {theta1_2, theta2_6, theta3_6, theta4_6, theta5_3, theta6_3},
                                                    {theta1_2, theta2_7, theta3_7, theta4_7, theta5_4, theta6_4},
                                                    {theta1_2, theta2_8, theta3_8, theta4_8, theta5_4, theta6_4}};
                //第一组解显示
                textBox19.Text = Math.Round(InverseSolvtion[0, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox18.Text = Math.Round(InverseSolvtion[0, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox17.Text = Math.Round(InverseSolvtion[0, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox16.Text = Math.Round(InverseSolvtion[0, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox15.Text = Math.Round(InverseSolvtion[0, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox14.Text = Math.Round(InverseSolvtion[0, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
                //第二组解显示
                textBox25.Text = Math.Round(InverseSolvtion[1, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox24.Text = Math.Round(InverseSolvtion[1, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox23.Text = Math.Round(InverseSolvtion[1, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox22.Text = Math.Round(InverseSolvtion[1, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox24.Text = Math.Round(InverseSolvtion[1, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox20.Text = Math.Round(InverseSolvtion[1, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
                //第三组解显示
                textBox31.Text = Math.Round(InverseSolvtion[2, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox30.Text = Math.Round(InverseSolvtion[2, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox29.Text = Math.Round(InverseSolvtion[2, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox28.Text = Math.Round(InverseSolvtion[2, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox27.Text = Math.Round(InverseSolvtion[2, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox26.Text = Math.Round(InverseSolvtion[2, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
                //第四组解显示
                textBox37.Text = Math.Round(InverseSolvtion[3, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox36.Text = Math.Round(InverseSolvtion[3, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox35.Text = Math.Round(InverseSolvtion[3, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox34.Text = Math.Round(InverseSolvtion[3, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox33.Text = Math.Round(InverseSolvtion[3, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox32.Text = Math.Round(InverseSolvtion[3, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
                //第五组解显示
                textBox43.Text = Math.Round(InverseSolvtion[4, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox42.Text = Math.Round(InverseSolvtion[4, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox41.Text = Math.Round(InverseSolvtion[4, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox40.Text = Math.Round(InverseSolvtion[4, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox39.Text = Math.Round(InverseSolvtion[4, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox38.Text = Math.Round(InverseSolvtion[4, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
                //第六组解显示
                textBox49.Text = Math.Round(InverseSolvtion[5, 0] * 180 / Pi - OffSet[0, 0], 2).ToString();
                textBox48.Text = Math.Round(InverseSolvtion[5, 1] * 180 / Pi - OffSet[0, 1], 2).ToString();
                textBox47.Text = Math.Round(InverseSolvtion[5, 2] * 180 / Pi - OffSet[0, 2], 2).ToString();
                textBox46.Text = Math.Round(InverseSolvtion[5, 3] * 180 / Pi - OffSet[0, 3], 2).ToString();
                textBox45.Text = Math.Round(InverseSolvtion[5, 4] * 180 / Pi - OffSet[0, 4], 2).ToString();
                textBox44.Text = Math.Round(InverseSolvtion[5, 5] * 180 / Pi - OffSet[0, 5], 2).ToString();
                //第七组解显示
                textBox55.Text = Math.Round(InverseSolvtion[6, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox54.Text = Math.Round(InverseSolvtion[6, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox53.Text = Math.Round(InverseSolvtion[6, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox52.Text = Math.Round(InverseSolvtion[6, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox51.Text = Math.Round(InverseSolvtion[6, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox50.Text = Math.Round(InverseSolvtion[6, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
                //第八组解显示
                textBox61.Text = Math.Round(InverseSolvtion[7, 0] * 180 / Pi + OffSet[0, 0], 2).ToString();
                textBox60.Text = Math.Round(InverseSolvtion[7, 1] * 180 / Pi + OffSet[0, 1], 2).ToString();
                textBox59.Text = Math.Round(InverseSolvtion[7, 2] * 180 / Pi + OffSet[0, 2], 2).ToString();
                textBox58.Text = Math.Round(InverseSolvtion[7, 3] * 180 / Pi + OffSet[0, 3], 2).ToString();
                textBox57.Text = Math.Round(InverseSolvtion[7, 4] * 180 / Pi + OffSet[0, 4], 2).ToString();
                textBox56.Text = Math.Round(InverseSolvtion[7, 5] * 180 / Pi + OffSet[0, 5], 2).ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Theta[0, 0] = float.Parse(textBox1.Text);
            Theta[0, 1] = float.Parse(textBox2.Text);
            Theta[0, 2] = float.Parse(textBox3.Text);
            Theta[0, 3] = float.Parse(textBox4.Text);
            Theta[0, 4] = float.Parse(textBox5.Text);
            Theta[0, 5] = float.Parse(textBox6.Text);
            Zj(Theta);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Nj();
            InverSolvtion(X, Y, Z, r, p, y);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }
    }
}
