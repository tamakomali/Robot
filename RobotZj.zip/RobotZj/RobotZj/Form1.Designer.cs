﻿namespace RobotZj
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(781, 141);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "正解";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(463, 69);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(93, 28);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(595, 69);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(93, 28);
            this.textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(727, 69);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(93, 28);
            this.textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(859, 69);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(93, 28);
            this.textBox4.TabIndex = 4;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(991, 69);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(93, 28);
            this.textBox5.TabIndex = 5;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(1123, 69);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(93, 28);
            this.textBox6.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(780, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 7;
            this.label1.Text = "六轴角度";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(767, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "末端位置姿态";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(1123, 258);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(93, 28);
            this.textBox7.TabIndex = 14;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(991, 258);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(93, 28);
            this.textBox8.TabIndex = 13;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(859, 258);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(93, 28);
            this.textBox9.TabIndex = 12;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(727, 258);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(93, 28);
            this.textBox10.TabIndex = 11;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(595, 258);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(93, 28);
            this.textBox11.TabIndex = 10;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(463, 258);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(93, 28);
            this.textBox12.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(490, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 18);
            this.label3.TabIndex = 15;
            this.label3.Text = "轴1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(620, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 18);
            this.label4.TabIndex = 16;
            this.label4.Text = "轴2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(750, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 18);
            this.label5.TabIndex = 17;
            this.label5.Text = "轴3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(880, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 18);
            this.label6.TabIndex = 18;
            this.label6.Text = "轴4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1010, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 18);
            this.label7.TabIndex = 19;
            this.label7.Text = "轴5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1140, 120);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 18);
            this.label8.TabIndex = 20;
            this.label8.Text = "轴6";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1140, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 18);
            this.label9.TabIndex = 26;
            this.label9.Text = "YAW";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1010, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 18);
            this.label10.TabIndex = 25;
            this.label10.Text = "PITCH";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(880, 223);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 18);
            this.label11.TabIndex = 24;
            this.label11.Text = "RALL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(750, 223);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 18);
            this.label12.TabIndex = 23;
            this.label12.Text = "Z";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(620, 223);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 18);
            this.label13.TabIndex = 22;
            this.label13.Text = "Y";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(490, 223);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 18);
            this.label14.TabIndex = 21;
            this.label14.Text = "X";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(781, 305);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 54);
            this.button2.TabIndex = 27;
            this.button2.Text = "逆解";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(753, 388);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 18);
            this.label15.TabIndex = 40;
            this.label15.Text = "轴6";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(623, 388);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 18);
            this.label16.TabIndex = 39;
            this.label16.Text = "轴5";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(493, 388);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 18);
            this.label17.TabIndex = 38;
            this.label17.Text = "轴4";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(363, 388);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 18);
            this.label18.TabIndex = 37;
            this.label18.Text = "轴3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(233, 388);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 18);
            this.label19.TabIndex = 36;
            this.label19.Text = "轴2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(103, 388);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 18);
            this.label20.TabIndex = 35;
            this.label20.Text = "轴1";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(727, 419);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(93, 28);
            this.textBox14.TabIndex = 34;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(595, 419);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(93, 28);
            this.textBox15.TabIndex = 33;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(463, 419);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(93, 28);
            this.textBox16.TabIndex = 32;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(331, 419);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(93, 28);
            this.textBox17.TabIndex = 31;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(199, 419);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(93, 28);
            this.textBox18.TabIndex = 30;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(67, 419);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(93, 28);
            this.textBox19.TabIndex = 29;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(727, 471);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(93, 28);
            this.textBox20.TabIndex = 46;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(595, 471);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(93, 28);
            this.textBox21.TabIndex = 45;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(463, 471);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(93, 28);
            this.textBox22.TabIndex = 44;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(331, 471);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(93, 28);
            this.textBox23.TabIndex = 43;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(199, 471);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(93, 28);
            this.textBox24.TabIndex = 42;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(67, 471);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(93, 28);
            this.textBox25.TabIndex = 41;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(727, 530);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(93, 28);
            this.textBox26.TabIndex = 52;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(595, 530);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(93, 28);
            this.textBox27.TabIndex = 51;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(463, 530);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(93, 28);
            this.textBox28.TabIndex = 50;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(331, 530);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(93, 28);
            this.textBox29.TabIndex = 49;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(199, 530);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(93, 28);
            this.textBox30.TabIndex = 48;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(67, 530);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(93, 28);
            this.textBox31.TabIndex = 47;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(727, 590);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(93, 28);
            this.textBox32.TabIndex = 58;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(595, 590);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(93, 28);
            this.textBox33.TabIndex = 57;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(463, 590);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(93, 28);
            this.textBox34.TabIndex = 56;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(331, 590);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(93, 28);
            this.textBox35.TabIndex = 55;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(199, 590);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(93, 28);
            this.textBox36.TabIndex = 54;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(67, 590);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(93, 28);
            this.textBox37.TabIndex = 53;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(727, 649);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(93, 28);
            this.textBox38.TabIndex = 64;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(595, 649);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(93, 28);
            this.textBox39.TabIndex = 63;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(463, 649);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(93, 28);
            this.textBox40.TabIndex = 62;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(331, 649);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(93, 28);
            this.textBox41.TabIndex = 61;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(199, 649);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(93, 28);
            this.textBox42.TabIndex = 60;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(67, 649);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(93, 28);
            this.textBox43.TabIndex = 59;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(727, 712);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(93, 28);
            this.textBox44.TabIndex = 70;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(595, 712);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(93, 28);
            this.textBox45.TabIndex = 69;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(463, 712);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(93, 28);
            this.textBox46.TabIndex = 68;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(331, 712);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(93, 28);
            this.textBox47.TabIndex = 67;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(199, 712);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(93, 28);
            this.textBox48.TabIndex = 66;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(67, 712);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(93, 28);
            this.textBox49.TabIndex = 65;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(1518, 419);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(93, 28);
            this.textBox50.TabIndex = 76;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(1386, 419);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(93, 28);
            this.textBox51.TabIndex = 75;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(1254, 419);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(93, 28);
            this.textBox52.TabIndex = 74;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(1122, 419);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(93, 28);
            this.textBox53.TabIndex = 73;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(990, 419);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(93, 28);
            this.textBox54.TabIndex = 72;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(858, 419);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(93, 28);
            this.textBox55.TabIndex = 71;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(1518, 481);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(93, 28);
            this.textBox56.TabIndex = 82;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(1386, 481);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(93, 28);
            this.textBox57.TabIndex = 81;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(1254, 481);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(93, 28);
            this.textBox58.TabIndex = 80;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(1122, 481);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(93, 28);
            this.textBox59.TabIndex = 79;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(990, 481);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(93, 28);
            this.textBox60.TabIndex = 78;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(858, 481);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(93, 28);
            this.textBox61.TabIndex = 77;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(26, 422);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(17, 18);
            this.label21.TabIndex = 83;
            this.label21.Text = "1";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(26, 481);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 18);
            this.label22.TabIndex = 84;
            this.label22.Text = "2";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(26, 540);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 18);
            this.label23.TabIndex = 85;
            this.label23.Text = "3";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(26, 600);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 18);
            this.label24.TabIndex = 86;
            this.label24.Text = "4";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(26, 652);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 18);
            this.label25.TabIndex = 87;
            this.label25.Text = "5";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(26, 715);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 18);
            this.label26.TabIndex = 88;
            this.label26.Text = "6";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(826, 422);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 18);
            this.label27.TabIndex = 89;
            this.label27.Text = "7";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(826, 481);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 18);
            this.label28.TabIndex = 90;
            this.label28.Text = "8";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1539, 388);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(35, 18);
            this.label29.TabIndex = 96;
            this.label29.Text = "轴6";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1409, 388);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 18);
            this.label30.TabIndex = 95;
            this.label30.Text = "轴5";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1279, 388);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 18);
            this.label31.TabIndex = 94;
            this.label31.Text = "轴4";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(1149, 388);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 18);
            this.label32.TabIndex = 93;
            this.label32.Text = "轴3";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(1019, 388);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 18);
            this.label33.TabIndex = 92;
            this.label33.Text = "轴2";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(889, 388);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(35, 18);
            this.label34.TabIndex = 91;
            this.label34.Text = "轴1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1630, 803);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "         ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
    }
}

